package com.acorn.erp.domain.Customer.Entity;

import lombok.Data;

@Data
public class Exam {
	private Long id;
	private String useremail;
	private String userpassword;
}
